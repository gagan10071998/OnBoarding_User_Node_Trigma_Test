module.exports = {
    en: require('./en')
}