module.exports = {
    signup: {
        _id: 1,
        email: 1,
        firstName: 1,
        lastName: 1,
        phone: 1,
        dob: 1,
        countryCode: 1,
        authToken: 1,
        status: 1
    }
}