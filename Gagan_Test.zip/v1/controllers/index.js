module.exports = {
    user: require('./user')
}