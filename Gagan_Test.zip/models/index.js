module.exports = {
    user: require('./user'),
    otp: require('./otp'),
    ObjectId: require('mongoose').Types.ObjectId
}